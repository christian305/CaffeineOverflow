﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Cs358_Program5
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader inFile;
            StreamWriter writer;

            string inLine;
            
            if (File.Exists(@"Students.txt"))
            {
                using (inFile = new StreamReader(@"Students.txt"))
                {

                    while ((inLine = inFile.ReadLine()) != null)
                    {
                        try
                        {
                      

                            int gpacount = 0;
                            int andersoncount = 0;
                            int peoplecount = 0;
                            int emailcount = 0;
                            double gpamean = 0;
                            double gpasum = 0;
                            double gpaR = 0;
                            int gpaamount = 0;
                            
                            int start = inLine.IndexOf(" '");

                            if (start >= 0)
                            {

                                //Gets all the last names
                                start = inLine.IndexOf(" '");
                                inLine = inLine.Substring(start + 2);
                                int end = inLine.IndexOf(" ");
                                string lastname = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);


                                //gets all the first names
                                start = inLine.IndexOf(" '");
                                inLine = inLine.Substring(start + 2);
                                end = inLine.IndexOf(" ");
                                string firstname = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);
                                if (firstname.IndexOf("") >= 0) peoplecount++;
                                if (firstname.IndexOf("Anderson") >= 0) andersoncount++;

                                //gets all the middle initials
                                start = inLine.IndexOf(" '");
                                inLine = inLine.Substring(start + 2);
                                end = inLine.IndexOf(" ");
                                string middlename = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);

                                //gets all the phone numbers
                                start = inLine.IndexOf(" '");
                                inLine = inLine.Substring(start + 2);
                                end = inLine.IndexOf(" ");
                                string phone = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);

                                //gets all the emails
                                start = inLine.IndexOf(" '");
                                inLine = inLine.Substring(start + 2);
                                end = inLine.IndexOf(" ");
                                string email = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);

                                if (email.IndexOf("NONE") >= 0)
                                {
                                    emailcount = emailcount + 1;
                                }


                                //gets all the gpa's
                                start = inLine.IndexOf(" ");
                                inLine = inLine.Substring(start + 1);
                                end = inLine.IndexOf(" ");
                                string gpa = inLine.Substring(0, end);
                                inLine = inLine.Substring(end);
                                if (gpa.CompareTo("3.") >= 0) gpacount++;
                                if (gpa.IndexOf("")>=0)
                                {
                                    gpasum = gpacount;
                                    gpamean = (gpasum + gpaR) / gpaamount;
                                }

                                Console.WriteLine("There are :"+emailcount+" Missing a Email Addresses.");
                                Console.WriteLine("There are :"+andersoncount + " Andersons in this class.");
                                Console.WriteLine("There are :"+peoplecount+" total student in this class");

                            }

                            
                        }
                        catch (System.IO.IOException exc)
                        {
                        Console.WriteLine("exception");
                        }
                        

                    }
                    
                }
            }

        }
        //(LIST (LIST 'Constant 'Malachi 'NONE ) '8125468312 'mconstant@mail.usi.edu 4.000000000000 )
    }
}
